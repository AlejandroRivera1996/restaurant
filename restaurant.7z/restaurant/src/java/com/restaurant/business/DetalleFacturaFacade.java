/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.restaurant.business;

import com.restaurant.entities.DetalleFactura;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author 1022416139
 */
@Stateless
public class DetalleFacturaFacade extends AbstractFacade<DetalleFactura> {

    @PersistenceContext(unitName = "restaurantPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DetalleFacturaFacade() {
        super(DetalleFactura.class);
    }
    
    public List<Object> listaFacturaMes(){
        List<Object> lista = new ArrayList<>();
        String sql = "select c.nombre, c.apellido1, c.apellido2, " +
            "EXTRACT(MONTH FROM f.fechafactura) as mes, " +
            "sum(coalesce(d.importe,0)) as suma " +
            "from restaurant.camarero c " +
            "left outer join restaurant.factura f on f.idcamarero = c.idcamarero " +
            "left outer join restaurant.detallefactura d on d.idfactura = f.idfactura " +
            "group by c.nombre, c.apellido1, c.apellido2,f.fechafactura "
            + "order by mes asc ";
        try{
            Query query = getEntityManager().createNativeQuery(sql);
            lista = query.getResultList();
        }catch(Exception e){
            e.printStackTrace();
        }
        return lista;
    }
    
}
