/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.restaurant.business;

import com.restaurant.entities.Platos;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author 1022416139
 */
@Stateless
public class PlatoFacade extends AbstractFacade<Platos> {

    @PersistenceContext(unitName = "restaurantPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PlatoFacade() {
        super(Platos.class);
    }
    
    
    
    
}
