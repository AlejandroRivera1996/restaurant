/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.restaurant.entities;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 1022416139
 */
@Entity
@Table(name = "detallefactura", catalog = "restaurant", schema = "restaurant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DetalleFactura.findAll", query = "SELECT d FROM DetalleFactura d")
    , @NamedQuery(name = "DetalleFactura.findByIddetallefactura", query = "SELECT d FROM DetalleFactura d WHERE d.iddetallefactura = :iddetallefactura")
    , @NamedQuery(name = "DetalleFactura.findByPlato", query = "SELECT d FROM DetalleFactura d WHERE d.plato = :plato")
    , @NamedQuery(name = "DetalleFactura.findByImporte", query = "SELECT d FROM DetalleFactura d WHERE d.importe = :importe")})
public class DetalleFactura implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "iddetallefactura", nullable = false)
    private Integer iddetallefactura;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "plato", nullable = false, length = 50)
    private String plato;
    @Basic(optional = false)
    @NotNull
    @Column(name = "importe", nullable = false)
    private BigInteger importe;
    @JoinColumn(name = "idcocinero", referencedColumnName = "idcocinero", nullable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Cocinero idcocinero;
    @JoinColumn(name = "idfactura", referencedColumnName = "idfactura", nullable = false)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Factura idfactura;

    public DetalleFactura() {
    }

    public DetalleFactura(Integer iddetallefactura) {
        this.iddetallefactura = iddetallefactura;
    }

    public DetalleFactura(Integer iddetallefactura, String plato, BigInteger importe) {
        this.iddetallefactura = iddetallefactura;
        this.plato = plato;
        this.importe = importe;
    }

    public Integer getIddetallefactura() {
        return iddetallefactura;
    }

    public void setIddetallefactura(Integer iddetallefactura) {
        this.iddetallefactura = iddetallefactura;
    }

    public String getPlato() {
        return plato;
    }

    public void setPlato(String plato) {
        this.plato = plato;
    }

    public BigInteger getImporte() {
        return importe;
    }

    public void setImporte(BigInteger importe) {
        this.importe = importe;
    }

    public Cocinero getIdcocinero() {
        return idcocinero;
    }

    public void setIdcocinero(Cocinero idcocinero) {
        this.idcocinero = idcocinero;
    }

    public Factura getIdfactura() {
        return idfactura;
    }

    public void setIdfactura(Factura idfactura) {
        this.idfactura = idfactura;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iddetallefactura != null ? iddetallefactura.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DetalleFactura)) {
            return false;
        }
        DetalleFactura other = (DetalleFactura) object;
        if ((this.iddetallefactura == null && other.iddetallefactura != null) || (this.iddetallefactura != null && !this.iddetallefactura.equals(other.iddetallefactura))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.restaurant.entities.DetalleFactura[ iddetallefactura=" + iddetallefactura + " ]";
    }
    
}
