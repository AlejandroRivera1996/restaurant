package com.restaurant.controler;

import com.restaurant.business.CamareroFacade;
import com.restaurant.business.ClienteFacade;
import com.restaurant.business.DetalleFacturaFacade;
import com.restaurant.entities.Factura;
import com.restaurant.entities.Cliente;
import com.restaurant.entities.Camarero;
import com.restaurant.entities.Mesa;
import com.restaurant.entities.DetalleFactura;
import com.restaurant.controler.util.JsfUtil;
import com.restaurant.controler.util.JsfUtil.PersistAction;
import com.restaurant.business.FacturaFacade;
import com.restaurant.business.MesaFacade;
import com.restaurant.business.PlatoFacade;
import com.restaurant.entities.Platos;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;


@Named("facturaController")
@SessionScoped
public class FacturaController implements Serializable {

    @EJB
    private com.restaurant.business.FacturaFacade ejbFacadeFactura;
    @EJB
    private com.restaurant.business.ClienteFacade ejbFacadeCliente;
    @EJB
    private com.restaurant.business.CamareroFacade ejbFacadeCamarero;
    @EJB
    private com.restaurant.business.MesaFacade ejbFacadeMesa;
    @EJB
    private com.restaurant.business.DetalleFacturaFacade ejbFacadeDetalleFactura;
    @EJB
    private com.restaurant.business.PlatoFacade ejbFacadePlatos;
    
    private List<Factura> items = null;
    private Factura selected;
    private Cliente clienteSelect;
    private Camarero camareroSelect;
    private Mesa mesaSelect;
    private DetalleFactura detalleSelect;
    private Platos plato;
    private Boolean selectCarta;
    private List<Platos> platos;
    private List<Platos> SelectePlatos;

            
            
    public FacturaController() {
    }

   
    
    protected void setEmbeddableKeys() {
    }

    protected void initializeEmbeddableKey() {
    }

    private FacturaFacade getFacade() {
        return ejbFacadeFactura;
    }

    public Factura prepareCreate() {
        selected = new Factura();
        initializeEmbeddableKey();
        prepareCreateCliente();
        prepareCreateCamarero();
        prepareMesa();
        prepareDetalle();
        preparePlatos();
        return selected;
    }
    
    
    public Camarero prepareCreateCamarero() {
        camareroSelect = new Camarero();
        initializeEmbeddableKey();
        return camareroSelect;
    }
    
    public Cliente prepareCreateCliente() {
        clienteSelect = new Cliente();
        initializeEmbeddableKey();
        return clienteSelect;
    }
    
    public Mesa prepareMesa(){
        mesaSelect = new Mesa();
        initializeEmbeddableKey();
        return mesaSelect;
    }
        public DetalleFactura prepareDetalle(){
        detalleSelect = new DetalleFactura();
        initializeEmbeddableKey();
        return detalleSelect;
    }
    
    public List<Platos> preparePlatos(){
        platos = new ArrayList();
        initializeEmbeddableKey();
        SelectePlatos = new ArrayList();
        platos = ejbFacadePlatos.findAll();
        return platos;
    }
    
    public void listener(){
//        if (){
//            
//        }
    }
            
    public void create() {

        try{
        Cliente cliente = ejbFacadeCliente.findObjectCliente(clienteSelect.getNombre(),
                     clienteSelect.getApellido1());
        if (cliente ==null){
            cliente = ejbFacadeCliente.create(clienteSelect);
        }
        Camarero camarero=ejbFacadeCamarero.findObjectCamarero(camareroSelect.getNombre()
                ,camareroSelect.getApellido1());
        if (camarero == null){
            camarero=ejbFacadeCamarero.create(camareroSelect);
        }
        Mesa mesa = ejbFacadeMesa.find(mesaSelect.getIdmesa());
        
        selected.setIdcliente(cliente);
        selected.setIdcamarero(camarero);
        selected.setIdmesa(mesa);
       
        Factura factura =ejbFacadeFactura.create(selected);
        
        for(Platos platoSelect : SelectePlatos){
            detalleSelect.setIdfactura(factura);
            detalleSelect.setPlato(platoSelect.getDescripcion());
            detalleSelect.setImporte(platoSelect.getValor());
            detalleSelect.setIdcocinero(platoSelect.getIdcocinero());
            ejbFacadeDetalleFactura.create(detalleSelect);
        }
        
        if (!JsfUtil.isValidationFailed()) {
            items = null;    // Invalidate list of items to trigger re-query.
        }
        }catch(Exception e){
            e.getMessage();
        }
    }

    public void update() {
        persist(PersistAction.UPDATE, ResourceBundle.getBundle("/Bundle").getString("FacturaUpdated"));
    }

    public void destroy() {
        persist(PersistAction.DELETE, ResourceBundle.getBundle("/Bundle").getString("FacturaDeleted"));
        if (!JsfUtil.isValidationFailed()) {
            selected = null; // Remove selection
            items = null;    // Invalidate list of items to trigger re-query.
        }
    }

    public List<Factura> getItems() {
        if (items == null) {
            items = getFacade().findAll();
        }
        return items;
    }

    private void persist(PersistAction persistAction, String successMessage) {
        if (selected != null) {
            setEmbeddableKeys();
            try {
                if (persistAction != PersistAction.DELETE) {
                    getFacade().edit(selected);
                } else {
                    getFacade().remove(selected);
                }
                JsfUtil.addSuccessMessage(successMessage);
            } catch (EJBException ex) {
                String msg = "";
                Throwable cause = ex.getCause();
                if (cause != null) {
                    msg = cause.getLocalizedMessage();
                }
                if (msg.length() > 0) {
                    JsfUtil.addErrorMessage(msg);
                } else {
                    JsfUtil.addErrorMessage(ex, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
                }
            } catch (Exception ex) {
                Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
                JsfUtil.addErrorMessage(ex, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            }
        }
    }

    public Factura getFactura(java.lang.Integer id) {
        return getFacade().find(id);
    }

    public List<Factura> getItemsAvailableSelectMany() {
        return getFacade().findAll();
    }

    public List<Factura> getItemsAvailableSelectOne() {
        return getFacade().findAll();
    }

    @FacesConverter(forClass = Factura.class)
    public static class FacturaControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            FacturaController controller = (FacturaController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "facturaController");
            return controller.getFactura(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof Factura) {
                Factura o = (Factura) object;
                return getStringKey(o.getIdfactura());
            } else {
                Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "object {0} is of type {1}; expected type: {2}", new Object[]{object, object.getClass().getName(), Factura.class.getName()});
                return null;
            }
        }

    }
    
     public Factura getSelected() {
        return selected;
    }

    public void setSelected(Factura selected) {
        this.selected = selected;
    }

    public FacturaFacade getEjbFacadeFactura() {
        return ejbFacadeFactura;
    }

    public void setEjbFacadeFactura(FacturaFacade ejbFacadeFactura) {
        this.ejbFacadeFactura = ejbFacadeFactura;
    }

    public ClienteFacade getEjbFacadeCliente() {
        return ejbFacadeCliente;
    }

    public void setEjbFacadeCliente(ClienteFacade ejbFacadeCliente) {
        this.ejbFacadeCliente = ejbFacadeCliente;
    }

    public Cliente getClienteSelect() {
        return clienteSelect;
    }

    public void setClienteSelect(Cliente clienteSelect) {
        this.clienteSelect = clienteSelect;
    }

    public CamareroFacade getEjbFacadeCamarero() {
        return ejbFacadeCamarero;
    }

    public void setEjbFacadeCamarero(CamareroFacade ejbFacadeCamarero) {
        this.ejbFacadeCamarero = ejbFacadeCamarero;
    }

    public Camarero getCamareroSelect() {
        return camareroSelect;
    }

    public void setCamareroSelect(Camarero camareroSelect) {
        this.camareroSelect = camareroSelect;
    }

    public MesaFacade getEjbFacadeMesa() {
        return ejbFacadeMesa;
    }

    public void setEjbFacadeMesa(MesaFacade ejbFacadeMesa) {
        this.ejbFacadeMesa = ejbFacadeMesa;
    }

    public Mesa getMesaSelect() {
        return mesaSelect;
    }

    public void setMesaSelect(Mesa mesaSelect) {
        this.mesaSelect = mesaSelect;
    }

    public DetalleFacturaFacade getEjbFacadeDetalleFactura() {
        return ejbFacadeDetalleFactura;
    }

    public void setEjbFacadeDetalleFactura(DetalleFacturaFacade ejbFacadeDetalleFactura) {
        this.ejbFacadeDetalleFactura = ejbFacadeDetalleFactura;
    }

    public PlatoFacade getEjbFacadePlatos() {
        return ejbFacadePlatos;
    }

    public void setEjbFacadePlatos(PlatoFacade ejbFacadePlatos) {
        this.ejbFacadePlatos = ejbFacadePlatos;
    }



    public Platos getPlato() {
        return plato;
    }

    public void setPlato(Platos plato) {
        this.plato = plato;
    }

    public List<Platos> getPlatos() {
        return platos;
    }

    public void setPlatos(List<Platos> platos) {
        this.platos = platos;
    }

    public List<Platos> getSelectePlatos() {
        return SelectePlatos;
    }

    public void setSelectePlatos(List<Platos> SelectePlatos) {
        this.SelectePlatos = SelectePlatos;
    }

    public DetalleFactura getDetalleSelect() {
        return detalleSelect;
    }

    public void setDetalleSelect(DetalleFactura detalleSelect) {
        this.detalleSelect = detalleSelect;
    }

    public Boolean getSelectCarta() {
        return selectCarta;
    }

    public void setSelectCarta(Boolean selectCarta) {
        this.selectCarta = selectCarta;
    }
    
}
